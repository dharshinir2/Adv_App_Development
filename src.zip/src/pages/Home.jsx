import CustomNavbar from "../components/customnavbar"

const Home=()=>{
    return(
        <div>
            <header>

            <CustomNavbar/>
            </header>
            <main>
                <section>
                    <p>Home page it is</p>


                </section>
            </main>

        </div>
    )
}
export default Home