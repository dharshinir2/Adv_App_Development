import CustomNavbar from "../components/customnavbar"

const About=()=>{
    return(
        <div>
            <header>

            <CustomNavbar/>
            </header>
            <main>
                <section>
                    <p>Your About Us page is one of the first supporting pages you’ll likely design when building your website, regardless of the industry you’re in.

It may go by different labels—About, Story, Mission—but these types of pages serve the same key purpose: to be the page for a brand to say, “This is who we are.”</p>

                </section>
            </main>

        </div>
    )
}
export default About