import CustomNavbar from "../components/customnavbar"

const Contact=()=>{
    return(
        <div>
            <header>

            <CustomNavbar/>
            </header>
            <main>
                <section>
                    <p>Contact page</p>


                </section>
            </main>

        </div>
    )
}
export default Contact