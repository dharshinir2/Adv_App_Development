import { RouterProvider, createBrowserRouter } from "react-router-dom"

import Home from "./pages/Home"
import { Suspense, lazy } from "react"
import Spinner from "./components/Spinner"
const LazyAbout=lazy(()=>import('./pages/About'));
const LazyContact=lazy(()=>import('./pages/Contact'));

const App=()=> {
  const router=createBrowserRouter([
    {
      path:'/home',
      element:<Suspense fallback={<Spinner/>}><Home/></Suspense>
    },
    {
      path:'/contact',
      element:<Suspense fallback={<Spinner/>}><LazyContact></LazyContact></Suspense>
    },
    {
      path:'/about',
      element:<Suspense fallback={<Spinner/>}><LazyAbout></LazyAbout></Suspense>
    }

  ])
 

  return (
    <>
    <RouterProvider router={router}/>
      
    </>
  )
}

export default App
